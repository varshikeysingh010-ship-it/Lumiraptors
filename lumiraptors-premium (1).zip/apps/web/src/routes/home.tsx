import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { organizationJsonLd } from '@/lib/organization';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { Hero } from '@/components/home/hero';
import { Mystery } from '@/components/home/mystery';
import { Climb } from '@/components/home/climb';
import { Audience } from '@/components/home/audience';
import { EarlyAccess } from '@/components/home/early-access';
import { Apply } from '@/components/home/apply';
import { BlogPreview } from '@/components/home/blog-preview';
import { Faq } from '@/components/home/faq';
import { Contact } from '@/components/home/contact';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'LumiRaptors | Real work. Real wings.',
    description: 'Something is taking shape. Built quietly for the ones with the hunger. Join the LumiRaptors early list and be there when the curtain opens.',
    jsonLd: organizationJsonLd,
  });
}

export default function HomePage() {
  return <><a className="skip-link" href="#the-mystery">Skip to content</a><SiteHeader /><main><Hero /><Mystery /><Climb /><Audience /><EarlyAccess /><Apply /><BlogPreview /><Faq /><Contact /></main><SiteFooter /></>;
}
