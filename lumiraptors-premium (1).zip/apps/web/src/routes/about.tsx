import type { Route } from './+types/about';
import { seo } from '@/lib/seo';
import { organizationJsonLd } from '@/lib/organization';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { AboutHero } from '@/components/about/page-hero';
import { TeamGrid } from '@/components/about/team-grid';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'About LumiRaptors | Founders and Team',
    description: 'Meet the people behind LumiRaptors — founder Chandra Prakash Kushwaha and co-founder and CEO Varshikey Singh. Real work. Real wings.',
    jsonLd: organizationJsonLd,
  });
}

export default function AboutPage() {
  return (
    <>
      <a className="skip-link" href="#team">Skip to content</a>
      <SiteHeader />
      <main>
        <AboutHero />
        <TeamGrid />
      </main>
      <SiteFooter />
    </>
  );
}
