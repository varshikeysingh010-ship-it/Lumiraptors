import type { Route } from './+types/student';
import { seo } from '@/lib/seo';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { FlashProvider } from '@/components/flash-provider';
import { StudentHero } from '@/components/student/page-hero';
import { ProjectGrid } from '@/components/student/project-grid';
import { CustomFit } from '@/components/student/custom-fit';
import { HowItWorks } from '@/components/student/how-it-works';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Students | LumiRaptors',
    description: 'Real projects. Real experience. Pick your climb — project-based internships in marketing, content and research, with a certificate on every finish.',
  });
}

export default function StudentPage() {
  return (
    <>
      <a className="skip-link" href="#student-main">Skip to content</a>
      <SiteHeader />
      <main id="student-main">
        <FlashProvider>
          <StudentHero />
          <ProjectGrid />
          <CustomFit />
          <HowItWorks />
        </FlashProvider>
      </main>
      <SiteFooter />
    </>
  );
}
