import type { Route } from './+types/blog.$slug';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { ReadingProgress } from '@/components/blog/reading-progress';
import { ShareButtons } from '@/components/blog/share-buttons';
import { AuthorBox } from '@/components/blog/author-box';
import { RelatedPosts } from '@/components/blog/related-posts';
import { CtaStrip } from '@/components/blog/cta-strip';
import { Reveal } from '@/components/reveal';
import { renderMarkdown } from '@/lib/markdown';
import { formatDate } from '@/lib/format-date';
import { getPostBySlug, getRelatedPosts } from '@/data/posts';
import { ArrowUpRight } from 'lucide-react';

export async function loader({ params }: Route.LoaderArgs) {
  const post = getPostBySlug(params.slug);
  if (!post) {
    throw new Response('Post not found', { status: 404 });
  }
  return { post };
}

export function meta({ matches, location, loaderData }: Route.MetaArgs) {
  if (!loaderData) {
    return seo({ matches, location }, {
      title: 'Post not found',
      description: 'This story is no longer published.',
      noindex: true,
    });
  }

  const { post } = loaderData;
  const origin = siteOriginFrom(matches);
  const url = absoluteUrl(origin, location.pathname);

  return seo({ matches, location }, {
    title: post.title,
    description: post.excerpt,
    image: post.coverImage,
    type: 'article',
    jsonLd: [
      {
        '@context': 'https://schema.org',
        '@type': 'Article',
        headline: post.title,
        description: post.excerpt,
        url,
        image: absoluteUrl(origin, post.coverImage),
        datePublished: post.date,
        author: { '@type': 'Person', name: post.author.name },
      },
      {
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        itemListElement: [
          { '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
          { '@type': 'ListItem', position: 2, name: 'Blog', item: absoluteUrl(origin, '/blog') },
          { '@type': 'ListItem', position: 3, name: post.title, item: url },
        ],
      },
    ],
  });
}

export default function BlogPostPage({ loaderData }: Route.ComponentProps) {
  const { post } = loaderData;
  const related = getRelatedPosts(post);

  return (
    <>
      <ReadingProgress />
      <a className="skip-link" href="#post-content">Skip to content</a>
      <SiteHeader />
      <main>
        <article className="post-article">
          <div className="post-header">
            <div className="section-rail post-header-rail">
              <Reveal>
                <a className="back-to-blog" href="/blog">← Back to blog</a>
                <span className="category-pill">{post.category}</span>
                <h1>{post.title}</h1>
                <div className="post-meta post-header-meta">
                  <span className="post-author-line">
                    <span className="author-avatar small" aria-hidden="true">V</span>
                    By {post.author.name}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{formatDate(post.date)}</span>
                  <span aria-hidden="true">·</span>
                  <span>{post.readingTime}</span>
                </div>
              </Reveal>
            </div>
          </div>

          <div className="post-cover-wrap">
            <div className="section-rail">
              <Reveal>
                <img
                  className="post-cover-image"
                  src={post.coverImage}
                  alt=""
                  width="1280"
                  height="720"
                  fetchPriority="high"
                />
              </Reveal>
            </div>
          </div>

          <div className="section-rail post-content" id="post-content">
            <Reveal>
              <div className="article-body">{renderMarkdown(post.content)}</div>
              <ShareButtons slug={post.slug} title={post.title} />
              <AuthorBox author={post.author} />
            </Reveal>
          </div>
        </article>

        <div className="section-rail">
          <RelatedPosts posts={related} />
        </div>

        <CtaStrip />
      </main>
      <SiteFooter />
    </>
  );
}
