import type { Route } from './+types/llms.txt';
import { siteOrigin } from '@/lib/site-origin.server';
import { posts } from '@/data/posts';

export async function loader({ request }: Route.LoaderArgs) {
  const origin = siteOrigin(request);

  const lines = [
    '# LumiRaptors',
    '',
    '> Stories, lessons and ideas from the road to launch.',
    '',
    '## Pages',
    `- [Blog](${origin}/blog): Every note, newest first.`,
    `- [About](${origin}/about): The people behind LumiRaptors.`,
  ];

  for (const post of [...posts].sort((a, b) => b.date.localeCompare(a.date))) {
    lines.push(`- [${post.title}](${origin}/blog/${post.slug}): ${post.excerpt}`);
  }

  return new Response(`${lines.join('\n')}\n`, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'public, max-age=3600',
    },
  });
}
