import type { Route } from './+types/rss.xml';
import { siteOrigin } from '@/lib/site-origin.server';
import { posts } from '@/data/posts';

function escapeXml(value: string): string {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&apos;');
}

export async function loader({ request }: Route.LoaderArgs) {
  const origin = siteOrigin(request);

  const items = [...posts]
    .sort((a, b) => b.date.localeCompare(a.date))
    .map(post => {
      const url = `${origin}/blog/${post.slug}`;
      return `\t\t<item>
\t\t\t<title>${escapeXml(post.title)}</title>
\t\t\t<link>${escapeXml(url)}</link>
\t\t\t<guid isPermaLink="true">${escapeXml(url)}</guid>
\t\t\t<description>${escapeXml(post.excerpt)}</description>
\t\t\t<category>${escapeXml(post.category)}</category>
\t\t\t<pubDate>${new Date(post.date).toUTCString()}</pubDate>
\t\t</item>`;
    })
    .join('\n');

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
\t<channel>
\t\t<title>LumiRaptors Blog</title>
\t\t<link>${escapeXml(origin)}/blog</link>
\t\t<description>Stories, lessons and ideas from the road to launch.</description>
\t\t<language>en-us</language>
${items}
\t</channel>
</rss>
`;

  return new Response(xml, {
    headers: {
      'Content-Type': 'application/rss+xml; charset=utf-8',
      'Cache-Control': 'public, max-age=3600',
    },
  });
}
