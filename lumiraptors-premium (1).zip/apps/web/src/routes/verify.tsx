import type { Route } from './+types/verify';
import { useLoaderData } from 'react-router';
import { seo } from '@/lib/seo';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { VerifyHero } from '@/components/verify/verify-hero';
import { VerifyPanel } from '@/components/verify/verify-panel';
import { VERIFY_ENDPOINT, type VerifyLoaderData } from '@/lib/verify';

export async function loader({ url }: Route.LoaderArgs): Promise<VerifyLoaderData> {
	const id = (url.searchParams.get('id') ?? '').trim();

	if (!id) {
		return { result: null, error: null, id: '' };
	}

	try {
		const res = await fetch(`${VERIFY_ENDPOINT}?id=${encodeURIComponent(id)}`);

		if (!res.ok) {
			throw new Error(`${res.status} ${res.statusText}`);
		}

		const data = (await res.json()) as VerifyLoaderData['result'];
		return { result: data, error: null, id };
	} catch {
		return { result: null, error: 'request-failed', id };
	}
}

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Verify a Certificate | LumiRaptors',
		description:
			'Enter the certificate ID printed on a LumiRaptors certificate to confirm it is genuine and valid.',
	});
}

export default function VerifyPage() {
	const data = useLoaderData<typeof loader>();

	return (
		<>
			<a className="skip-link" href="#verify">Skip to content</a>
			<SiteHeader />
			<main>
				<VerifyHero />
				<VerifyPanel data={data} />
			</main>
			<SiteFooter />
		</>
	);
}
