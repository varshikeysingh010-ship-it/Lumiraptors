import type { Route } from './+types/startup';
import { seo } from '@/lib/seo';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { FlashProvider } from '@/components/flash-provider';
import { StartupHero } from '@/components/startup/page-hero';
import { ProcessPoints } from '@/components/startup/process-points';
import { FormSection } from '@/components/startup/form-section';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Startups | LumiRaptors',
    description: 'Got work waiting to be done? Tell us the task — we find the right talent and quality-check it before it reaches you.',
  });
}

export default function StartupPage() {
  return (
    <>
      <a className="skip-link" href="#startup-main">Skip to content</a>
      <SiteHeader />
      <main id="startup-main">
        <FlashProvider>
          <StartupHero />
          <ProcessPoints />
          <FormSection />
        </FlashProvider>
      </main>
      <SiteFooter />
    </>
  );
}
