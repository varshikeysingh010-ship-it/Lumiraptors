import { useState } from 'react';
import type { Route } from './+types/blog';
import { seo } from '@/lib/seo';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { FeaturedPost } from '@/components/blog/featured-post';
import { PostCard } from '@/components/blog/post-card';
import { Reveal } from '@/components/reveal';
import { posts, categories } from '@/data/posts';
import { Search } from 'lucide-react';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'The LumiRaptors Blog',
    description: 'Stories, lessons and ideas from the road to launch — careers, startups, learning and behind the scenes.',
  });
}

const PAGE_SIZE = 6;
const FILTERS = ['All', ...categories] as const;

export default function BlogPage() {
  const [activeCategory, setActiveCategory] = useState<(typeof FILTERS)[number]>('All');
  const [query, setQuery] = useState('');
  const [visible, setVisible] = useState(PAGE_SIZE);

  const filtered = posts.filter(post => {
    const matchesCategory = activeCategory === 'All' || post.category === activeCategory;
    const q = query.trim().toLowerCase();
    const matchesQuery =
      q === '' ||
      post.title.toLowerCase().includes(q) ||
      post.excerpt.toLowerCase().includes(q);
    return matchesCategory && matchesQuery;
  });

  const searching = query.trim() !== '';
  const featured = searching ? null : filtered.find(post => post.featured) ?? filtered[0] ?? null;
  const gridPosts = featured ? filtered.filter(post => post.slug !== featured.slug) : filtered;
  const shown = gridPosts.slice(0, visible);
  const hasMore = gridPosts.length > visible;

  return (
    <>
      <a className="skip-link" href="#blog-main">Skip to content</a>
      <SiteHeader />
      <main id="blog-main">
        <section className="blog-hero">
          <div className="section-rail">
            <Reveal>
              <span className="eyebrow">THE LUMIRAPTORS BLOG</span>
              <h1>Notes from the <span className="gold-text">climb.</span></h1>
              <p>Stories, lessons and ideas from the road to launch.</p>
            </Reveal>
          </div>
        </section>

        <section className="blog-controls">
          <div className="section-rail">
            <div className="blog-controls-row">
              <div className="category-chips" role="group" aria-label="Filter posts by category">
                {FILTERS.map(filter => (
                  <button
                    key={filter}
                    type="button"
                    className={`category-chip${activeCategory === filter ? ' is-active' : ''}`}
                    aria-pressed={activeCategory === filter}
                    onClick={() => { setActiveCategory(filter); setVisible(PAGE_SIZE); }}
                  >
                    {filter}
                  </button>
                ))}
              </div>
              <div className="blog-search">
                <Search size={16} strokeWidth={1.6} />
                <input
                  type="search"
                  placeholder="Search posts…"
                  value={query}
                  onChange={event => { setQuery(event.target.value); setVisible(PAGE_SIZE); }}
                  aria-label="Search posts"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="section blog-listing">
          <div className="section-rail">
            {filtered.length === 0 ? (
              <Reveal>
                <div className="blog-empty">
                  <h3>No notes match that yet.</h3>
                  <p>Try a different category or search term.</p>
                </div>
              </Reveal>
            ) : (
              <>
                {featured && <FeaturedPost post={featured} />}
                {gridPosts.length > 0 && (
                  <>
                    {featured && <h2 className="blog-grid-title">More from the climb</h2>}
                    <div className="post-grid">
                      {shown.map((post, index) => (
                        <PostCard key={post.slug} post={post} delay={(index % 3) * 0.08} />
                      ))}
                    </div>
                    {hasMore && (
                      <div className="blog-load-more">
                        <button
                          type="button"
                          className="button button-outline"
                          onClick={() => setVisible(value => value + PAGE_SIZE)}
                        >
                          Load more posts
                        </button>
                      </div>
                    )}
                  </>
                )}
              </>
            )}
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
