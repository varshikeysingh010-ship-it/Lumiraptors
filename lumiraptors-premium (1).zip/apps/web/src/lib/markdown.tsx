import { Fragment, type ReactNode } from 'react';

/**
 * A tiny, deterministic markdown renderer for blog post content. Supports:
 * ## / ### headings, > blockquotes, - bullet lists, ![alt](url) images,
 * **bold** and [link](url) inline. No dependencies, SSR-safe.
 */

function renderInline(text: string): ReactNode[] {
  const pattern = /(\*\*([^*]+)\*\*|\[([^\]]+)\]\(([^)]+)\))/g;
  const nodes: ReactNode[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let key = 0;

  while ((match = pattern.exec(text)) !== null) {
    if (match.index > lastIndex) {
      nodes.push(text.slice(lastIndex, match.index));
    }
    if (match[2] !== undefined) {
      nodes.push(<strong key={key++}>{match[2]}</strong>);
    } else if (match[3] !== undefined) {
      nodes.push(
        <a key={key++} href={match[4]} target="_blank" rel="noopener noreferrer">
          {match[3]}
        </a>,
      );
    }
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < text.length) {
    nodes.push(text.slice(lastIndex));
  }

  return nodes;
}

export function renderMarkdown(markdown: string): ReactNode[] {
  const lines = markdown.split('\n');
  const blocks: ReactNode[] = [];
  let list: string[] = [];
  let key = 0;

  const flushList = () => {
    if (list.length === 0) return;
    const items = [...list];
    blocks.push(
      <ul key={`ul-${key++}`}>
        {items.map((item, i) => (
          <li key={i}>{renderInline(item)}</li>
        ))}
      </ul>,
    );
    list = [];
  };

  for (const raw of lines) {
    const line = raw.trimEnd();

    if (line.startsWith('### ')) {
      flushList();
      blocks.push(<h3 key={`h3-${key++}`}>{renderInline(line.slice(4))}</h3>);
    } else if (line.startsWith('## ')) {
      flushList();
      blocks.push(<h2 key={`h2-${key++}`}>{renderInline(line.slice(3))}</h2>);
    } else if (line.startsWith('> ')) {
      flushList();
      blocks.push(<blockquote key={`q-${key++}`}>{renderInline(line.slice(2))}</blockquote>);
    } else if (line.startsWith('- ')) {
      list.push(line.slice(2));
    } else if (/^!\[[^\]]*\]\([^)]+\)$/.test(line.trim())) {
      flushList();
      const match = line.trim().match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
      if (match) {
        blocks.push(
          <img
            key={`img-${key++}`}
            src={match[2]}
            alt={match[1]}
            loading="lazy"
          />,
        );
      }
    } else if (line.trim() === '') {
      flushList();
    } else {
      flushList();
      blocks.push(<p key={`p-${key++}`}>{renderInline(line)}</p>);
    }
  }

  flushList();
  return blocks.map((block, i) => <Fragment key={i}>{block}</Fragment>);
}
