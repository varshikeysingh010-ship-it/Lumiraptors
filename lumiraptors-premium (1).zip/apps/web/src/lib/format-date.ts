/**
 * Deterministic date formatting for SSR. Uses a fixed locale and UTC so the
 * server and client render identical strings (no hydration mismatch).
 */
export function formatDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC',
  });
}
