export type CertResult = {
	found: boolean;
	name?: string;
	project?: string;
	startup?: string;
	date?: string;
	duration?: string;
	status?: string;
};

export type VerifyLoaderData = {
	result: CertResult | null;
	error: string | null;
	id: string;
};

/** Google Apps Script endpoint that returns a single certificate record as JSON. */
export const VERIFY_ENDPOINT =
	'https://script.google.com/macros/s/AKfycbxc3WtdqXaZ2iv_iR9zL1UgJmsmBx9SozBIsICgWgliKvJ8o6QDk6oBWhZOlGHshU8krw/exec';
