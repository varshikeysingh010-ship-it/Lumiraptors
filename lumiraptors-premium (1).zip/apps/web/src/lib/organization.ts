import { site } from '@/constants/site';

/**
 * Organization structured data for LumiRaptors. Added to the <head> of the
 * home and About pages via each route's `meta` export (`seo()` renders every
 * `jsonLd` entry as its own `<script type="application/ld+json">`).
 *
 * `logo` uses the real public URL of the site's logo image; `url` is the
 * preferred canonical domain the site publishes under.
 */
export const organizationJsonLd = {
	'@context': 'https://schema.org',
	'@type': 'Organization',
	name: 'LumiRaptors',
	url: 'https://lumiraptors.com',
	logo: 'https://lumiraptors.com/logo-icon.png',
	slogan: 'Real work. Real wings.',
	email: site.email,
	address: {
		'@type': 'PostalAddress',
		addressLocality: 'Deoria',
		addressRegion: 'Uttar Pradesh',
		postalCode: '274001',
		addressCountry: 'IN',
	},
	sameAs: [site.linkedin, site.instagram],
	founder: [
		{
			'@type': 'Person',
			name: 'Chandra Prakash Kushwaha',
			jobTitle: 'Founder',
		},
		{
			'@type': 'Person',
			name: 'Varshikey Singh',
			jobTitle: 'Co-Founder and CEO',
			sameAs: ['https://www.linkedin.com/in/varshikey-singh-702b8a367'],
		},
	],
};
