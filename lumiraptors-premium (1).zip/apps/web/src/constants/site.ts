export const site = {
  name: 'LumiRaptors',
  logo: '/logo-mark.png',
  logoIcon: '/logo-icon.png',
  mountains: 'https://images.hostinger.com/5cbf96e1-f65b-4856-807e-156b926bb1ab.png',
  // Replace with an ISO date including timezone, e.g. 2027-01-01T18:00:00+05:30.
  // Fixed IST launch target — 8 November 2026, 8:00 PM India Standard Time (UTC+5:30).
  launchDate: '2026-11-08T20:00:00+05:30',
  studentForm: '[STUDENT GOOGLE FORM LINK]',
  startupForm: '[STARTUP GOOGLE FORM LINK]',
  email: 'Lumiraptors@gmail.com',
  whatsapp: '+91 91960 47377',
  linkedin: 'https://www.linkedin.com/company/lumiraptors/',
  instagram: 'https://www.instagram.com/lumiraptors',
  location: 'Deoria, Uttar Pradesh, India',
  contactLocation: 'Jhansi, Uttar Pradesh, India',
};

export const navigation = [
  { label: 'Home', href: '#home' },
  { label: 'The Climb', href: '#the-climb' },
  { label: "Who It’s For", href: '#who-its-for' },
  { label: 'Apply', href: '#apply' },
  { label: 'Blog', href: '/blog' },
  { label: 'About', href: '/about' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Contact', href: '#contact' },
];

export function isConfigured(value: string) {
  return Boolean(value) && !value.startsWith('[');
}
