import { type RouteConfig, index, route } from '@react-router/dev/routes';

export default [
	index('routes/home.tsx'),
	route('about', 'routes/about.tsx'),
	route('verify', 'routes/verify.tsx'),
	route('student', 'routes/student.tsx'),
	route('startup', 'routes/startup.tsx'),
	route('blog', 'routes/blog.tsx'),
	route('blog/:slug', 'routes/blog.$slug.tsx'),
	route('rss.xml', 'routes/rss.xml.ts'),
	route('llms.txt', 'routes/llms.txt.ts'),
	route('sitemap.xml', 'routes/sitemap.xml.ts'),
	route('robots.txt', 'routes/robots.txt.ts'),
	route('api/health', 'routes/api.health.ts'),
	route('api/*', 'routes/api.$.ts'),
] satisfies RouteConfig;
