import { useEffect, useState } from 'react';
import { useLocation } from 'react-router';
import { ArrowUpRight, Menu, X } from 'lucide-react';
import { navigation, site } from '@/constants/site';

export function SiteHeader() {
  const { pathname } = useLocation();
  const onHome = pathname === '/';
  const linkHref = (href: string) => href.startsWith('#') && !onHome ? `/${href}` : href;
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => { const update = () => setScrolled(window.scrollY > 24); update(); window.addEventListener('scroll', update, { passive: true }); return () => window.removeEventListener('scroll', update); }, []);
  useEffect(() => { if (!open) return; const close = (event: KeyboardEvent) => { if (event.key === 'Escape') setOpen(false); }; window.addEventListener('keydown', close); return () => window.removeEventListener('keydown', close); }, [open]);
  return <header className={`site-header ${scrolled || open ? 'is-scrolled' : ''}`}>
    <a className="brand" href={linkHref('#home')} aria-label="LumiRaptors home" onClick={() => setOpen(false)}><img src={site.logo} alt="" aria-hidden="true" width="48" height="43" /><span>LUMI<span>RAPTORS</span></span></a>
    <nav className="desktop-nav" aria-label="Main navigation">{navigation.map(link => <a key={link.href} href={linkHref(link.href)}>{link.label}</a>)}</nav>
    <a className="button button-gold header-cta" href={linkHref('#early-access')}>Get Early Access <ArrowUpRight size={15} /></a>
    <button className="menu-toggle" aria-label={open ? 'Close navigation' : 'Open navigation'} aria-expanded={open} aria-controls="mobile-navigation" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
    {open && <nav id="mobile-navigation" className="mobile-nav" aria-label="Mobile navigation">{navigation.map(link => <a key={link.href} href={linkHref(link.href)} onClick={() => setOpen(false)}>{link.label}</a>)}<a className="button button-gold" href={linkHref('#early-access')} onClick={() => setOpen(false)}>Get Early Access <ArrowUpRight size={16} /></a></nav>}
  </header>;
}
