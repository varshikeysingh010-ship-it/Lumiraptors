import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { isConfigured } from '@/constants/site';

type TriggerFn = (message: string, formUrl: string) => void;

const FlashContext = createContext<TriggerFn>(() => {});

/**
 * Renders the soft gold-white flash overlay and the top-center toast, and opens
 * the target form in a new tab once the flash has played. Wrap any page that
 * uses `FlashFormButton` in this provider.
 */
export function FlashProvider({ children }: { children: ReactNode }) {
  const [flash, setFlash] = useState(false);
  const [toast, setToast] = useState<{ visible: boolean; message: string }>({
    visible: false,
    message: '',
  });
  const reduced = useReducedMotion();

  const trigger = useCallback(
    (message: string, formUrl: string) => {
      setToast({ visible: true, message });
      if (!reduced) {
        setFlash(true);
        window.setTimeout(() => setFlash(false), 320);
      }
      const openDelay = reduced ? 250 : 360;
      window.setTimeout(() => {
        if (isConfigured(formUrl)) {
          window.open(formUrl, '_blank', 'noopener,noreferrer');
        }
      }, openDelay);
      window.setTimeout(() => setToast(current => ({ ...current, visible: false })), 2000);
    },
    [reduced],
  );

  return (
    <FlashContext.Provider value={trigger}>
      {children}
      <AnimatePresence>
        {flash && (
          <motion.div
            className="flash-overlay"
            aria-hidden="true"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16, ease: 'easeOut' }}
          />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {toast.visible && (
          <motion.div
            className="flash-toast"
            role="status"
            initial={{ opacity: 0, x: '-50%', y: -16 }}
            animate={{ opacity: 1, x: '-50%', y: 0 }}
            exit={{ opacity: 0, x: '-50%', y: -16 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
          >
            {toast.message}
          </motion.div>
        )}
      </AnimatePresence>
    </FlashContext.Provider>
  );
}

export const useFlash = () => useContext(FlashContext);
