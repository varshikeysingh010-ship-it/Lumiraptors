import { useEffect, useState } from 'react';
import { useLocation } from 'react-router';

/**
 * Plays a brief soft gold fade across the viewport whenever the route path
 * changes. Client-only: the overlay starts hidden on the server and on the
 * first client render, then the effect fires after hydration, so there is no
 * hydration mismatch.
 */
export function PageTransition() {
  const { pathname } = useLocation();
  const [active, setActive] = useState(false);

  useEffect(() => {
    setActive(true);
    const timer = window.setTimeout(() => setActive(false), 300);
    return () => window.clearTimeout(timer);
  }, [pathname]);

  if (!active) return null;
  return <div className="page-transition-overlay" aria-hidden="true" />;
}
