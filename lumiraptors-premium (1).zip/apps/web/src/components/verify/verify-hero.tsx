import { Reveal } from '@/components/reveal';

export function VerifyHero() {
	return (
		<section className="page-hero verify-hero">
			<div className="section-rail">
				<Reveal>
					<span className="eyebrow">CERTIFICATE VERIFICATION</span>
					<h1>
						Verify a <span className="gold-text">certificate.</span>
					</h1>
					<p>Enter the certificate ID printed on the certificate.</p>
				</Reveal>
			</div>
		</section>
	);
}
