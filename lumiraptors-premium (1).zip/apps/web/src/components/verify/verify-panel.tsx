import { Form, useNavigation } from 'react-router';
import { AlertTriangle, Loader2, SearchX, ShieldAlert, ShieldCheck } from 'lucide-react';
import { Reveal } from '@/components/reveal';
import type { VerifyLoaderData } from '@/lib/verify';

export function VerifyPanel({ data }: { data: VerifyLoaderData }) {
	const navigation = useNavigation();
	const isChecking = navigation.state === 'loading';
	const { result, error, id } = data;

	return (
		<section className="section verify-section" id="verify">
			<div className="section-rail verify-rail">
				<Reveal>
					<Form method="get" className="verify-form" role="search">
						<label htmlFor="cert-id">Certificate ID</label>
						<div className="signup-field">
							<input
								id="cert-id"
								name="id"
								type="text"
								defaultValue={id}
								placeholder="e.g. LR-2026-0001"
								autoComplete="off"
								spellCheck={false}
							/>
							<button type="submit" className="button button-gold flash-btn" disabled={isChecking}>
								{isChecking ? (
									<>
										<Loader2 size={16} className="spin" /> Checking…
									</>
								) : (
									'Verify'
								)}
							</button>
						</div>
					</Form>
				</Reveal>

				<div className="verify-result">
					{isChecking ? (
						<div className="verify-card verify-loading">
							<Loader2 size={28} className="spin" />
							<p>Checking certificate…</p>
						</div>
					) : error === 'request-failed' ? (
						<div className="verify-card verify-error">
							<AlertTriangle size={28} />
							<h3>Couldn’t reach the verification service</h3>
							<p>
								Something went wrong while checking this ID. Please try again in a moment, or email{' '}
								<a href="mailto:Lumiraptors@gmail.com">Lumiraptors@gmail.com</a>.
							</p>
						</div>
					) : result && result.found && result.status === 'Valid' ? (
						<div className="verify-card verify-valid">
							<div className="verify-card-head">
								<ShieldCheck size={30} />
								<span className="verify-badge">Verified</span>
							</div>
							<dl className="verify-details">
								<div>
									<dt>Name</dt>
									<dd>{result.name}</dd>
								</div>
								<div>
									<dt>Project</dt>
									<dd>{result.project}</dd>
								</div>
								<div>
									<dt>Startup</dt>
									<dd>{result.startup}</dd>
								</div>
								<div>
									<dt>Issue date</dt>
									<dd>{result.date}</dd>
								</div>
								<div>
									<dt>Duration</dt>
									<dd>{result.duration}</dd>
								</div>
							</dl>
						</div>
					) : result && result.found && result.status === 'Revoked' ? (
						<div className="verify-card verify-revoked">
							<ShieldAlert size={30} />
							<h3>This certificate has been revoked.</h3>
						</div>
					) : result && result.found ? (
						<div className="verify-card verify-notfound">
							<AlertTriangle size={28} />
							<h3>We couldn’t confirm this certificate.</h3>
							<p>
								Please check the ID and try again, or contact{' '}
								<a href="mailto:Lumiraptors@gmail.com">Lumiraptors@gmail.com</a>.
							</p>
						</div>
					) : result && result.found === false ? (
						<div className="verify-card verify-notfound">
							<SearchX size={28} />
							<h3>We couldn’t find this ID.</h3>
							<p>
								Please check it and try again, or contact{' '}
								<a href="mailto:Lumiraptors@gmail.com">Lumiraptors@gmail.com</a>.
							</p>
						</div>
					) : null}
				</div>

				<p className="verify-note">LumiRaptors verifies the details listed on the certificate only.</p>
			</div>
		</section>
	);
}
