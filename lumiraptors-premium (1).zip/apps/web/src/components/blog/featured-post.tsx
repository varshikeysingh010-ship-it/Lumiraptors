import { ArrowUpRight } from 'lucide-react';
import { Reveal } from '@/components/reveal';
import { formatDate } from '@/lib/format-date';
import type { Post } from '@/data/posts';

export function FeaturedPost({ post }: { post: Post }) {
  return (
    <Reveal>
      <article className="featured-post">
        <a className="featured-cover" href={`/blog/${post.slug}`} aria-label={post.title}>
          <img src={post.coverImage} alt="" loading="lazy" width="1280" height="720" />
          <span className="category-pill">{post.category}</span>
          <span className="featured-badge">Featured</span>
        </a>
        <div className="featured-body">
          <div className="post-meta">
            <span>{formatDate(post.date)}</span>
            <span aria-hidden="true">·</span>
            <span>{post.readingTime}</span>
            <span aria-hidden="true">·</span>
            <span>By {post.author.name}</span>
          </div>
          <h2>
            <a href={`/blog/${post.slug}`}>{post.title}</a>
          </h2>
          <p className="featured-excerpt">{post.excerpt}</p>
          <a className="button button-gold" href={`/blog/${post.slug}`}>
            Read the story <ArrowUpRight size={17} />
          </a>
        </div>
      </article>
    </Reveal>
  );
}
