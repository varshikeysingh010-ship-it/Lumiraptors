import { ArrowUpRight } from 'lucide-react';
import { Reveal } from '@/components/reveal';
import { formatDate } from '@/lib/format-date';
import type { Post } from '@/data/posts';

export function PostCard({ post, delay = 0 }: { post: Post; delay?: number }) {
  return (
    <Reveal delay={delay} className="post-card-wrap">
      <article className="post-card">
        <a className="post-cover" href={`/blog/${post.slug}`} aria-label={post.title}>
          <img src={post.coverImage} alt="" loading="lazy" width="640" height="360" />
          <span className="category-pill">{post.category}</span>
        </a>
        <div className="post-body">
          <h3>
            <a href={`/blog/${post.slug}`}>{post.title}</a>
          </h3>
          <p className="post-excerpt">{post.excerpt}</p>
          <div className="post-meta">
            <span>{formatDate(post.date)}</span>
            <span aria-hidden="true">·</span>
            <span>{post.readingTime}</span>
          </div>
          <a className="text-link read-more" href={`/blog/${post.slug}`}>
            Read more <ArrowUpRight size={15} />
          </a>
        </div>
      </article>
    </Reveal>
  );
}
