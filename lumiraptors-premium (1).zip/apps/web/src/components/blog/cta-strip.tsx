import { useState, type FormEvent } from 'react';
import { ArrowUpRight, CheckCircle2, LoaderCircle } from 'lucide-react';
import { pocketbaseClient } from '@/lib/pocketbase-client';

export function CtaStrip() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    if (data.get('website')) return;
    setStatus('loading');
    try {
      await pocketbaseClient.collection('early_access').create({
        email: String(data.get('email')).trim().toLowerCase(),
        consent: true,
      });
      setStatus('success');
      form.reset();
    } catch {
      setStatus('error');
    }
  }

  return (
    <section className="blog-cta">
      <div className="blog-cta-rail">
        {status === 'success' ? (
          <div className="success-panel" role="status">
            <CheckCircle2 size={26} />
            <div>
              <strong>You’re on the list.</strong>
              <p>You’ll hear from us when the light is on.</p>
            </div>
          </div>
        ) : (
          <>
            <div>
              <span className="eyebrow">FIRST IN. FIRST TO KNOW.</span>
              <h2>Be there when the<br />curtain <span className="gold-text">opens.</span></h2>
            </div>
            <form onSubmit={submit} className="blog-cta-form">
              <div className="signup-field">
                <input
                  id="cta-email"
                  name="email"
                  type="email"
                  placeholder="Enter your email address"
                  autoComplete="email"
                  required
                  maxLength={254}
                  disabled={status === 'loading'}
                />
                <button className="button button-gold" type="submit" disabled={status === 'loading'}>
                  {status === 'loading' ? (
                    <><LoaderCircle className="spin" size={17} /> Joining…</>
                  ) : (
                    <>Notify Me <ArrowUpRight size={17} /></>
                  )}
                </button>
              </div>
              <input className="honeypot" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" />
              {status === 'error' && (
                <p className="form-error" role="alert">We couldn’t save your email. Please try again.</p>
              )}
            </form>
          </>
        )}
      </div>
    </section>
  );
}
