import type { Post } from '@/data/posts';

export function AuthorBox({ author }: { author: Post['author'] }) {
  return (
    <div className="author-box">
      <div className="author-avatar" aria-hidden="true">V</div>
      <div>
        <span className="eyebrow">WRITTEN BY</span>
        <strong>{author.name}</strong>
        <p>{author.role}. Building LumiRaptors for the ones with the hunger but not yet the opening.</p>
      </div>
    </div>
  );
}
