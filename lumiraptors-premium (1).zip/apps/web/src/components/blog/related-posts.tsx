import { PostCard } from '@/components/blog/post-card';
import type { Post } from '@/data/posts';

export function RelatedPosts({ posts }: { posts: Post[] }) {
  if (posts.length === 0) return null;
  return (
    <section className="related-section">
      <span className="eyebrow">KEEP CLIMBING</span>
      <h2>Related <span className="gold-text">notes.</span></h2>
      <div className="post-grid">
        {posts.map((post, index) => (
          <PostCard key={post.slug} post={post} delay={index * 0.08} />
        ))}
      </div>
    </section>
  );
}
