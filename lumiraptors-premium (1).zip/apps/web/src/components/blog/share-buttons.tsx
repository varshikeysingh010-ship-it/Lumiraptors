import { useState } from 'react';
import { useMatches } from 'react-router';
import { Check, Link2, Linkedin, MessageCircle, Twitter } from 'lucide-react';

export function ShareButtons({ slug, title }: { slug: string; title: string }) {
  const matches = useMatches();
  const root = matches.find(match => match.id === 'root');
  const origin = (root?.loaderData as { origin?: string } | undefined)?.origin ?? '';
  const url = `${origin}/blog/${slug}`;
  const [copied, setCopied] = useState(false);

  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);

  const shares = [
    { label: 'LinkedIn', href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`, Icon: Linkedin },
    { label: 'WhatsApp', href: `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`, Icon: MessageCircle },
    { label: 'X', href: `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`, Icon: Twitter },
  ];

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="share-buttons">
      <span className="share-label">Share</span>
      <div className="share-icons">
        {shares.map(({ label, href, Icon }) => (
          <a
            key={label}
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Share on ${label}`}
            className="share-icon"
          >
            <Icon size={17} strokeWidth={1.6} />
          </a>
        ))}
        <button type="button" onClick={copyLink} aria-label="Copy link" className="share-icon">
          {copied ? <Check size={17} strokeWidth={1.8} /> : <Link2 size={17} strokeWidth={1.6} />}
        </button>
      </div>
    </div>
  );
}
