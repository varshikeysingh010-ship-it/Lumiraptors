import { motion, useScroll, useReducedMotion } from 'framer-motion';

export function ReadingProgress() {
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll();
  return (
    <motion.div
      className="reading-progress"
      style={reduced ? undefined : { scaleX: scrollYProgress }}
      aria-hidden="true"
    />
  );
}
