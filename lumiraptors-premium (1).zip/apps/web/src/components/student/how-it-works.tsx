import { Reveal } from '@/components/reveal';

const steps = [
  { number: '01', title: 'Apply', text: 'Pick a project and send your details.' },
  { number: '02', title: 'Get picked', text: 'We match you to the work that fits.' },
  { number: '03', title: 'Do the project', text: 'Real work, with mentor feedback along the way.' },
  { number: '04', title: 'Get your certificate', text: 'Finish strong and earn your proof.' },
];

export function HowItWorks() {
  return (
    <section className="section how-it-works-section">
      <div className="section-rail">
        <Reveal className="center-heading">
          <span className="eyebrow">HOW IT WORKS</span>
          <h2>Four steps to <span className="gold-text">something real.</span></h2>
        </Reveal>
        <div className="how-steps">
          {steps.map((step, index) => (
            <Reveal key={step.number} delay={index * 0.08} className="how-step">
              <span className="how-number">{step.number}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </Reveal>
          ))}
        </div>
        <Reveal className="how-note">
          Every project is reviewed before delivery, and every finished project earns a certificate.
        </Reveal>
      </div>
    </section>
  );
}
