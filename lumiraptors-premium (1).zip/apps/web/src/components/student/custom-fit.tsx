import { ArrowUpRight, Sparkles } from 'lucide-react';
import { Reveal } from '@/components/reveal';
import { FlashFormButton } from '@/components/flash-form-button';
import { site } from '@/constants/site';

export function CustomFit() {
  return (
    <section className="section custom-fit-section">
      <div className="section-rail">
        <Reveal>
          <article className="custom-fit-card">
            <span className="custom-fit-icon"><Sparkles size={26} strokeWidth={1.5} /></span>
            <h3>Don’t see your fit? Tell us what you want to learn.</h3>
            <p>If none of these match what you’re after, tell us. We’re always opening new doors.</p>
            <FlashFormButton href={site.studentForm} message="Let’s get you started!" className="button button-gold">
              Tell us what you want <ArrowUpRight size={18} />
            </FlashFormButton>
          </article>
        </Reveal>
      </div>
    </section>
  );
}
