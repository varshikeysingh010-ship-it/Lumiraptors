import { ArrowLeft } from 'lucide-react';
import { Reveal } from '@/components/reveal';

export function StudentHero() {
  return (
    <section className="page-hero student-hero">
      <div className="section-rail">
        <Reveal>
          <a className="back-to-home" href="/">
            <ArrowLeft size={15} /> Back to Home
          </a>
          <span className="eyebrow">FOR THE AMBITIOUS</span>
          <h1>Pick your <span className="gold-text">climb.</span></h1>
          <p>Real projects. Real experience. Choose the one that fits you.</p>
        </Reveal>
      </div>
    </section>
  );
}
