import { useState } from 'react';
import { ArrowUpRight, CalendarDays, Lock, Mail, PenLine, Search, Users } from 'lucide-react';
import { Reveal } from '@/components/reveal';
import { FlashFormButton } from '@/components/flash-form-button';
import { projects, projectCategories, type Project, type ProjectIcon } from '@/data/projects';
import { site } from '@/constants/site';

const icons: Record<ProjectIcon, typeof CalendarDays> = {
  calendar: CalendarDays,
  users: Users,
  search: Search,
  pen: PenLine,
  mail: Mail,
  lock: Lock,
};

const STUDENT_MESSAGE = "Great pick! Taking you to the form...";

function ProjectCard({ project, delay }: { project: Project; delay: number }) {
  const Icon = icons[project.icon];
  return (
    <Reveal delay={delay}>
      <article className={`project-card${project.comingSoon ? ' is-locked' : ''}`}>
        <div className="project-card-top">
          <span className="project-icon">
            <Icon size={24} strokeWidth={1.5} />
          </span>
          {project.comingSoon ? (
            <span className="project-level locked">Coming Soon</span>
          ) : (
            <span className={`project-level ${project.level.toLowerCase()}`}>{project.level}</span>
          )}
        </div>
        <h3>{project.title}</h3>
        <p className="project-desc">{project.description}</p>
        <div className="project-meta">
          <span><CalendarDays size={14} strokeWidth={1.6} /> {project.duration}</span>
        </div>
        <p className="project-gets"><span className="project-gets-label">What you’ll get:</span> {project.gets}</p>
        {project.comingSoon ? (
          <button type="button" className="button button-outline project-locked-btn" disabled>
            <Lock size={15} /> Coming Soon
          </button>
        ) : (
          <FlashFormButton href={site.studentForm} message={STUDENT_MESSAGE} className="button button-gold">
            Apply for this <ArrowUpRight size={17} />
          </FlashFormButton>
        )}
      </article>
    </Reveal>
  );
}

export function ProjectGrid() {
  const [active, setActive] = useState<(typeof projectCategories)[number]>('All');

  const filtered =
    active === 'All' ? projects : projects.filter(p => p.category === active);

  return (
    <section className="section project-section" id="projects">
      <div className="section-rail">
        <Reveal className="center-heading">
          <span className="eyebrow">PROJECT-BASED INTERNSHIPS</span>
          <h2>Open for <span className="gold-text">you.</span></h2>
          <p>Pick a project. Prove yourself. Build something real.</p>
        </Reveal>
        <div className="category-chips project-chips" role="group" aria-label="Filter projects by category">
          {projectCategories.map(category => (
            <button
              key={category}
              type="button"
              className={`category-chip${active === category ? ' is-active' : ''}`}
              aria-pressed={active === category}
              onClick={() => setActive(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className="project-grid">
          {filtered.map((project, index) => (
            <ProjectCard key={project.id} project={project} delay={(index % 3) * 0.07} />
          ))}
        </div>
      </div>
    </section>
  );
}
