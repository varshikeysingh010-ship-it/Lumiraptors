import { useRef, useState, type ReactNode } from 'react';
import { useReducedMotion } from 'framer-motion';
import { X } from 'lucide-react';
import { useFlash } from '@/components/flash-provider';
import { isConfigured } from '@/constants/site';

/**
 * A button that plays the soft gold flash + toast (via `FlashProvider`), glows
 * around itself, and then opens the form in a new tab. When the link is still a
 * placeholder, it shows the same coming-soon dialog as `ConfigurationLink`
 * instead of opening a broken tab.
 */
export function FlashFormButton({
  href,
  message,
  className = '',
  children,
}: {
  href: string;
  message: string;
  className?: string;
  children: ReactNode;
}) {
  const trigger = useFlash();
  const reduced = useReducedMotion();
  const [glow, setGlow] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);
  const configured = isConfigured(href);

  return (
    <>
      <button
        type="button"
        className={`${className} flash-btn${glow ? ' is-flashing' : ''}`}
        onClick={(event) => {
          event.preventDefault();
          if (!reduced) {
            setGlow(true);
            window.setTimeout(() => setGlow(false), 700);
          }
          trigger(message, href);
          if (!configured) {
            window.setTimeout(() => dialog.current?.showModal(), 420);
          }
        }}
      >
        {children}
      </button>
      <dialog
        ref={dialog}
        className="link-dialog"
        aria-label="Coming soon"
        onClick={(event) => {
          if (event.target === event.currentTarget) dialog.current?.close();
        }}
      >
        <button className="dialog-close" onClick={() => dialog.current?.close()} aria-label="Close">
          <X size={20} />
        </button>
        <span className="eyebrow">THE LIGHT IS ALMOST ON</span>
        <h2>Not long now.</h2>
        <p>This form hasn’t been published yet. Join the early list and be there when the curtain opens.</p>
        <a className="button button-gold" href="/#early-access" onClick={() => dialog.current?.close()}>
          Join the early list
        </a>
      </dialog>
    </>
  );
}
