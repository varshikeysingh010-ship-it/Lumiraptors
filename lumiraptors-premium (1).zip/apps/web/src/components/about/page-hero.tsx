import { ArrowLeft } from 'lucide-react';
import { Reveal } from '@/components/reveal';

export function AboutHero() {
  return (
    <section className="page-hero about-hero">
      <div className="section-rail">
        <Reveal>
          <a className="back-to-home" href="/">
            <ArrowLeft size={15} /> Back to Home
          </a>
          <span className="eyebrow">THE PEOPLE BEHIND LUMIRAPTORS</span>
          <h1>The people behind <span className="gold-text">LumiRaptors.</span></h1>
          <p>Real work. Real wings.</p>
        </Reveal>
      </div>
    </section>
  );
}
