import { Linkedin, MapPin } from 'lucide-react';
import { Reveal } from '@/components/reveal';
import { site } from '@/constants/site';

const team = [
  {
    initials: 'CP',
    name: 'Chandra Prakash Kushwaha',
    role: 'Founder',
    linkedin: '',
  },
  {
    initials: 'VS',
    name: 'Varshikey Singh',
    role: 'Co-Founder and CEO',
    linkedin: 'https://www.linkedin.com/in/varshikey-singh-702b8a367',
  },
];

export function TeamGrid() {
  return (
    <section className="section team-section" id="team">
      <div className="section-rail">
        <Reveal>
          <span className="eyebrow">WHO WE ARE</span>
          <h2 className="center-heading">Two people. <span className="gold-text">One climb.</span></h2>
        </Reveal>
        <div className="team-grid">
          {team.map((member, index) => (
            <Reveal key={member.name} direction={index === 0 ? 'left' : 'right'} delay={index * 0.1}>
              <article className="team-card">
                <div className="team-photo" aria-hidden="true">{member.initials}</div>
                <h3>{member.name}</h3>
                <p className="team-role">{member.role}</p>
                <p className="team-bio">&nbsp;</p>
                {member.linkedin && (
                  <a
                    className="team-linkedin"
                    href={member.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`${member.name} on LinkedIn`}
                  >
                    <Linkedin size={18} /> LinkedIn
                  </a>
                )}
              </article>
            </Reveal>
          ))}
        </div>
        <Reveal>
          <div className="team-location">
            <MapPin size={18} strokeWidth={1.5} />
            <span>{site.location}</span>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
