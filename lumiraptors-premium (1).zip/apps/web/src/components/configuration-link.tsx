import { useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';
import { isConfigured } from '@/constants/site';

export function ConfigurationLink({ href, children, className = '', label = 'This link' }: { href: string; children: ReactNode; className?: string; label?: string }) {
  const dialog = useRef<HTMLDialogElement>(null);
  return <>
    <a href={isConfigured(href) ? href : '#early-access'} target={isConfigured(href) ? '_blank' : undefined} rel="noopener noreferrer" className={className} onClick={(event) => { if (!isConfigured(href)) { event.preventDefault(); dialog.current?.showModal(); } }}>{children}</a>
    <dialog ref={dialog} className="link-dialog" aria-label="Coming soon" onClick={(event) => { if (event.target === event.currentTarget) dialog.current?.close(); }}>
      <button className="dialog-close" onClick={() => dialog.current?.close()} aria-label="Close"><X size={20} /></button>
      <span className="eyebrow">THE LIGHT IS ALMOST ON</span><h2>Not long now.</h2>
      <p>{label} hasn’t been announced yet. Join the early list and be there when the curtain opens.</p>
      <a className="button button-gold" href="#early-access" onClick={() => dialog.current?.close()}>Join the early list</a>
    </dialog>
  </>;
}
