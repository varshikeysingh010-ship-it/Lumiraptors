import { ArrowUpRight, Instagram, Linkedin } from 'lucide-react';
import { site, navigation } from '@/constants/site';
import { ConfigurationLink } from '@/components/configuration-link';

export function SiteFooter() {
  return <footer className="site-footer"><div className="section-rail"><div className="footer-main"><div><a href="#home" className="brand"><img src={site.logo} alt="" aria-hidden="true" width="56" height="50" loading="lazy" /><span>LUMI<span>RAPTORS</span></span></a><p className="footer-tagline">Real work. Real wings.</p></div><nav className="footer-links" aria-label="Footer navigation">{navigation.slice(1).map(link => <a href={link.href} key={link.href}>{link.label}</a>)}<a href="/verify">Verify</a></nav><div className="footer-socials"><ConfigurationLink href={site.linkedin} label="Our LinkedIn page"><span className="sr-only">LinkedIn</span><Linkedin size={18} /></ConfigurationLink><ConfigurationLink href={site.instagram} label="Our Instagram page"><span className="sr-only">Instagram</span><Instagram size={18} /></ConfigurationLink><a href="#home" aria-label="Back to top"><ArrowUpRight size={20} /></a></div></div><div className="footer-bottom"><p>© 2026 LumiRaptors. All rights reserved.</p><span>BUILT QUIETLY. AIMING HIGH.</span></div></div></footer>;
}
