import { ClipboardList, ShieldCheck, UserCheck } from 'lucide-react';
import { Reveal } from '@/components/reveal';

const points = [
  { icon: ClipboardList, title: 'Tell us the task', text: 'Share what needs doing.' },
  { icon: UserCheck, title: 'We find the right talent', text: 'Matched to your work.' },
  { icon: ShieldCheck, title: 'Quality-checked before it reaches you', text: 'Reviewed before delivery.' },
];

export function ProcessPoints() {
  return (
    <section className="section process-section">
      <div className="section-rail">
        <div className="process-grid">
          {points.map((point, index) => (
            <Reveal key={point.title} delay={index * 0.08} className="process-point">
              <span className="process-icon">
                <point.icon size={26} strokeWidth={1.5} />
              </span>
              <h3>{point.title}</h3>
              <p>{point.text}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
