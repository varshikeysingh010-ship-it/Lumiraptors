import { ArrowUpRight, Check, Clock3, Mail, MessageCircle } from 'lucide-react';
import { Reveal } from '@/components/reveal';
import { FlashFormButton } from '@/components/flash-form-button';
import { ConfigurationLink } from '@/components/configuration-link';
import { site, isConfigured } from '@/constants/site';

const formFields = [
  'Startup name',
  'Founder name',
  'Website or LinkedIn',
  'The task you need done',
  'Deadline',
  'Budget range',
];

export function FormSection() {
  return (
    <section className="section startup-form-section" id="startup-form">
      <div className="section-rail startup-form-rail">
        <Reveal className="startup-form-card">
          <span className="eyebrow">WHAT WE ASK</span>
          <h2>A few details. That’s all.</h2>
          <p>Fill the form and we’ll take it from there.</p>
          <span className="list-label">THE FORM ASKS FOR</span>
          <ul className="form-fields">
            {formFields.map(field => (
              <li key={field}><Check size={15} />{field}</li>
            ))}
          </ul>
          <FlashFormButton href={site.startupForm} message="Awesome! Let’s get your work moving." className="button button-gold startup-cta">
            Fill the Startup Form <ArrowUpRight size={18} />
          </FlashFormButton>
          <p className="form-note"><Clock3 size={13} /> Takes less than 2 minutes.</p>
        </Reveal>

        <Reveal className="prefer-talk" delay={0.1}>
          <span className="eyebrow">PREFER TO TALK FIRST?</span>
          <div className="prefer-talk-row">
            <ConfigurationLink className="prefer-talk-link" href={isConfigured(site.whatsapp) ? `https://wa.me/${site.whatsapp.replace(/\D/g, '')}` : site.whatsapp} label="Our WhatsApp contact">
              <MessageCircle size={18} strokeWidth={1.5} />
              <span><span className="prefer-talk-label">WhatsApp</span>{site.whatsapp}</span>
            </ConfigurationLink>
            <ConfigurationLink className="prefer-talk-link" href={isConfigured(site.email) ? `mailto:${site.email}` : site.email} label="Our email contact">
              <Mail size={18} strokeWidth={1.5} />
              <span><span className="prefer-talk-label">Email</span>{site.email}</span>
            </ConfigurationLink>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
