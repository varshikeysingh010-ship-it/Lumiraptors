import { ArrowLeft } from 'lucide-react';
import { Reveal } from '@/components/reveal';

export function StartupHero() {
  return (
    <section className="page-hero startup-hero">
      <div className="section-rail">
        <Reveal>
          <a className="back-to-home" href="/">
            <ArrowLeft size={15} /> Back to Home
          </a>
          <span className="eyebrow blue-label">FOR THE BUILDERS</span>
          <h1>Got work waiting<br />to be <span className="gold-text">done?</span></h1>
          <p>Tell us what you need. We’ll take it from here.</p>
        </Reveal>
      </div>
    </section>
  );
}
