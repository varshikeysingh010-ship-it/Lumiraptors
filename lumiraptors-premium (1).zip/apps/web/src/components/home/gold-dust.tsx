import { useEffect, useRef } from 'react';
import { useReducedMotion } from 'framer-motion';

type Mote = { x: number; y: number; r: number; vy: number; sway: number; phase: number; tw: number };

/**
 * Slow drifting gold dust behind the hero. Pauses when the hero is off-screen
 * or the tab is hidden, and renders nothing for people who prefer reduced motion.
 */
export function GoldDust() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const reduced = useReducedMotion();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || reduced) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let motes: Mote[] = [];
    let frame = 0;
    let running = false;
    let visible = true;

    const seed = () => {
      const count = width < 700 ? 26 : 56;
      motes = Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        r: 0.5 + Math.random() * 1.5,
        vy: 0.08 + Math.random() * 0.22,
        sway: 6 + Math.random() * 18,
        phase: Math.random() * Math.PI * 2,
        tw: 0.6 + Math.random() * 1.4,
      }));
    };

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = rect.width;
      height = rect.height;
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      seed();
    };

    const draw = (time: number) => {
      ctx.clearRect(0, 0, width, height);
      const t = time / 1000;
      for (const m of motes) {
        m.y -= m.vy;
        if (m.y < -8) { m.y = height + 8; m.x = Math.random() * width; }
        const x = m.x + Math.sin(t * 0.35 + m.phase) * m.sway;
        const twinkle = 0.35 + 0.65 * Math.abs(Math.sin(t * m.tw + m.phase));
        const edge = Math.min(1, Math.max(0, Math.min(m.y, height - m.y) / 120));
        const alpha = twinkle * edge;
        ctx.globalAlpha = alpha * 0.16;
        ctx.fillStyle = '#e6cb86';
        ctx.beginPath(); ctx.arc(x, m.y, m.r * 4, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = alpha * 0.85;
        ctx.fillStyle = '#f3e2ae';
        ctx.beginPath(); ctx.arc(x, m.y, m.r, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
    };

    const loop = (time: number) => {
      draw(time);
      frame = requestAnimationFrame(loop);
    };
    const start = () => { if (!running && visible && !document.hidden) { running = true; frame = requestAnimationFrame(loop); } };
    const stop = () => { running = false; cancelAnimationFrame(frame); };

    resize();
    start();
    const observer = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; if (visible) start(); else stop(); });
    observer.observe(canvas);
    const onVisibility = () => { if (document.hidden) stop(); else start(); };
    document.addEventListener('visibilitychange', onVisibility);
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(canvas);

    return () => {
      stop();
      observer.disconnect();
      resizeObserver.disconnect();
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [reduced]);

  return <canvas ref={canvasRef} className="gold-dust" aria-hidden="true" />;
}
