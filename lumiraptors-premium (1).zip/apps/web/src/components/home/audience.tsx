import { ArrowUpRight, GraduationCap, Rocket } from 'lucide-react';
import { Reveal } from '@/components/reveal';

export function Audience() {
  return <section className="section audience-section" id="who-its-for"><div className="section-rail">
    <Reveal className="audience-heading"><div><span className="eyebrow">WHO IT’S FOR</span><h2>Different beginnings.<br />The same <span className="gold-text">hunger.</span></h2></div><p>Some are looking for their first opening.<br />Some are ready to make one.</p></Reveal>
    <div className="two-column"><Reveal><article className="audience-card ambitious"><GraduationCap className="audience-watermark" strokeWidth={0.7} /><span className="eyebrow">THE NEXT GENERATION</span><GraduationCap className="audience-icon" size={30} strokeWidth={1.5} /><h3>For the Ambitious</h3><p>You’ve got the drive. You’ve done the learning.<br />Now you want something real.</p><a className="text-link" href="/student">Join the Early List <ArrowUpRight size={18} /></a></article></Reveal><Reveal delay={0.1}><article className="audience-card builders"><Rocket className="audience-watermark" strokeWidth={0.7} /><span className="eyebrow blue-label">THE ONES BUILDING WHAT’S NEXT</span><Rocket className="audience-icon" size={29} strokeWidth={1.5} /><h3>For the Builders</h3><p>You’re making something that matters.<br />You know great talent doesn’t always come with a spotlight.</p><a className="text-link" href="/startup">Partner With Us <ArrowUpRight size={18} /></a></article></Reveal></div>
  </div></section>;
}
