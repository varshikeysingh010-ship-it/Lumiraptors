import { useEffect, useRef, useState, type PointerEvent } from 'react';
import { ArrowDown, ArrowUpRight, GraduationCap, Rocket } from 'lucide-react';
import { motion, useMotionValue, useReducedMotion, useScroll, useSpring, useTransform } from 'framer-motion';
import { site } from '@/constants/site';
import { GoldDust } from '@/components/home/gold-dust';

const ease: [number, number, number, number] = [0.22, 1, 0.36, 1];

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 90]);
  const contentY = useTransform(scrollYProgress, [0, 1], [0, -48]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.75], [1, 0.15]);

  // The eagle leans gently toward the pointer.
  const px = useMotionValue(0);
  const py = useMotionValue(0);
  const sx = useSpring(px, { stiffness: 70, damping: 18, mass: 0.6 });
  const sy = useSpring(py, { stiffness: 70, damping: 18, mass: 0.6 });
  const rotateY = useTransform(sx, [-1, 1], [-9, 9]);
  const rotateX = useTransform(sy, [-1, 1], [7, -7]);
  const shiftX = useTransform(sx, [-1, 1], [-10, 10]);
  const shiftY = useTransform(sy, [-1, 1], [-6, 6]);
  const onPointerMove = (event: PointerEvent<HTMLElement>) => {
    if (reduced || event.pointerType === 'touch') return;
    const rect = event.currentTarget.getBoundingClientRect();
    px.set(((event.clientX - rect.left) / rect.width - 0.5) * 2);
    py.set(((event.clientY - rect.top) / rect.height - 0.5) * 2);
  };
  const onPointerLeave = () => { px.set(0); py.set(0); };

  const [remaining, setRemaining] = useState<number | null>(null);
  useEffect(() => {
    const target = Date.parse(site.launchDate);
    if (!Number.isFinite(target)) return;
    const tick = () => setRemaining(Math.max(0, target - Date.now()));
    tick(); const interval = window.setInterval(tick, 1000); return () => window.clearInterval(interval);
  }, []);
  const seconds = remaining === null ? null : Math.floor(remaining / 1000);
  const units = [seconds === null ? null : Math.floor(seconds / 86400), seconds === null ? null : Math.floor(seconds / 3600) % 24, seconds === null ? null : Math.floor(seconds / 60) % 60, seconds === null ? null : seconds % 60];

  // One orchestrated entrance: the light comes on, the eagle catches it, then the words arrive.
  const rise = (delay: number) => ({
    initial: reduced ? false : { opacity: 0, y: 18 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.9, delay, ease },
  });
  const line = (delay: number) => ({
    initial: reduced ? false : { y: '112%' },
    animate: { y: '0%' },
    transition: { duration: 1.05, delay, ease },
  });

  return <section className="hero" id="home" ref={ref} aria-labelledby="hero-title" onPointerMove={onPointerMove} onPointerLeave={onPointerLeave}>
    <motion.img className="hero-mountains" src={site.mountains} alt="" aria-hidden="true" style={{ y: reduced ? 0 : y }} fetchPriority="high" />
    <div className="hero-vignette" /><div className="hero-rays" aria-hidden="true" /><div className="hero-halo" />
    <GoldDust />
    <motion.div className="hero-content" style={reduced ? undefined : { y: contentY, opacity: contentOpacity }}>
      <motion.div className="launch-pill" {...rise(0.2)}><span /> A NEW CHAPTER IS COMING</motion.div>
      <motion.div className="hero-emblem" style={reduced ? undefined : { transformPerspective: 900, rotateX, rotateY, x: shiftX, y: shiftY }}>
        <svg className="emblem-ring" viewBox="0 0 100 100" fill="none" aria-hidden="true">
          <g className="ring-outer"><circle cx="50" cy="50" r="49" stroke="currentColor" strokeWidth="0.25" strokeDasharray="0.6 1.8" /><circle cx="50" cy="1" r="0.9" fill="#f3e2ae" /></g>
          <g className="ring-inner"><circle cx="50" cy="50" r="43" stroke="currentColor" strokeWidth="0.18" /><circle cx="50" cy="93" r="0.6" fill="#c9a45c" /></g>
        </svg>
        <motion.div className="emblem-stage" initial={reduced ? false : { opacity: 0, scale: 0.94, filter: 'brightness(0.12) saturate(0.4)' }} animate={{ opacity: 1, scale: 1, filter: 'brightness(1) saturate(1)' }} transition={{ duration: 2.2, delay: 0.35, ease }}>
          <img className="hero-logo" src={site.logo} alt="LumiRaptors golden geometric eagle" width="482" height="426" fetchPriority="high" />
          <span className="hero-glint" aria-hidden="true" />
        </motion.div>
      </motion.div>
      <motion.p className="hero-kicker" {...rise(1.5)}>Something is taking shape.</motion.p>
      <h1 id="hero-title"><span className="h-line"><motion.span {...line(1.7)}>Real work.</motion.span></span>{' '}<span className="h-line"><motion.span className="gold-text" {...line(1.85)}>Real wings.</motion.span></span></h1>
      <motion.p className="hero-subtext" {...rise(2.1)}>Built quietly for the ones who have the hunger<br className="desktop-break" /> but haven’t had the opening. <span>The light is almost on.</span></motion.p>
      <motion.div className="hero-actions" {...rise(2.3)}><a className="button button-gold" href="/student"><GraduationCap size={19} /> I’m a Student <ArrowUpRight size={17} /></a><a className="button button-outline" href="/startup"><Rocket size={18} /> I’m a Startup <ArrowUpRight size={17} /></a></motion.div>
      <motion.div className="countdown" {...rise(2.5)}><p className="countdown-label">THE COUNTDOWN TO SOMETHING REAL</p>{remaining === 0 ? <p className="countdown-open">The curtain is open.</p> : <div className="countdown-digits" role="timer" aria-label={remaining === null ? 'Launch date to be announced' : 'Time until launch'}>{units.map((value, index) => <div key={index}><motion.strong key={String(value)} initial={reduced || value === null ? false : { opacity: 0, y: -7 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, ease: 'easeOut' }}>{value === null ? '— —' : String(value).padStart(2, '0')}</motion.strong><span>{['DAYS', 'HOURS', 'MINUTES', 'SECONDS'][index]}</span></div>)}</div>}<p className="launch-date">Something big arrives on 8 November 2026, 8:00 PM IST</p></motion.div>
      <motion.a className="scroll-cue" href="#the-mystery" {...rise(2.7)}><span>THERE’S MORE BELOW</span><ArrowDown size={18} /></motion.a>
    </motion.div>
    <span className="hero-side-label" aria-hidden="true">LUMIRAPTORS · THE BEGINNING</span>
  </section>;
}
