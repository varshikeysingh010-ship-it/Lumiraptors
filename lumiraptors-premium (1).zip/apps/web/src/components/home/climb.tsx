import { ArrowUpRight } from 'lucide-react';
import { motion, useReducedMotion } from 'framer-motion';
import { Reveal } from '@/components/reveal';
import { climbSteps } from '@/data/content';
import { site } from '@/constants/site';

export function Climb() {
  const reduced = useReducedMotion();
  return <section className="climb-section section" id="the-climb"><img className="climb-background" src={site.mountains} alt="Dark mountains with a golden path leading to the summit" loading="lazy" /><div className="climb-shade" /><div className="section-rail climb-content">
    <Reveal className="climb-heading"><span className="eyebrow">THE CLIMB</span><h2>No shortcuts.<br />Just <span className="gold-text">up.</span></h2><p>You don’t need to see the whole mountain.<br />You just need to take the first step.</p></Reveal>
    <div className="climb-path"><svg viewBox="0 0 1000 250" fill="none" preserveAspectRatio="none" aria-hidden="true"><path d="M 50 220 C 250 220 300 165 450 140 S 700 90 940 25" stroke="currentColor" strokeWidth="1.5" strokeDasharray="5 8" vectorEffect="non-scaling-stroke" opacity="0.45" /><motion.path className="climb-line" d="M 50 220 C 250 220 300 165 450 140 S 700 90 940 25" stroke="#ecd59a" strokeWidth="1.75" strokeLinecap="round" initial={reduced ? false : { pathLength: 0 }} whileInView={{ pathLength: 1 }} viewport={{ once: true, amount: 0.4 }} transition={{ duration: 2.4, delay: 0.3, ease: [0.45, 0, 0.2, 1] }} /></svg>{climbSteps.map((step, index) => <Reveal key={step.title} className={`climb-step step-${index + 1}`} delay={0.35 + index * 0.85}><span className="step-dot"><ArrowUpRight size={19} /></span><span className="step-number">{step.number} / THE CLIMB</span><h3>{step.title}</h3><p>{step.text}</p></Reveal>)}</div>
    <span className="climb-caption">EVERY SUMMIT STARTS WITH SOMEONE WHO DIDN’T QUIT.</span>
  </div></section>;
}
