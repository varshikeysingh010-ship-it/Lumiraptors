import { Plus } from 'lucide-react';
import { Reveal } from '@/components/reveal';
import { faqs } from '@/data/content';

export function Faq() {
  return <section className="section faq-section" id="faq"><div className="faq-rail"><Reveal><span className="eyebrow">A FEW THINGS WE CAN SAY</span><h2>Good <span className="gold-text">questions.</span><br />Honest answers.</h2><p>A little clarity. A little mystery.<br />That’s where we are right now.</p></Reveal><Reveal className="faq-list">{faqs.map((faq, index) => <details className="faq-item" key={faq.question} name="lumiraptors-faq"><summary><span className="faq-number">0{index + 1}</span><span>{faq.question}</span><Plus size={19} /></summary><p>{faq.answer}</p></details>)}</Reveal></div></section>;
}
