import { DoorOpen, Eye, ShieldCheck } from 'lucide-react';
import { Reveal } from '@/components/reveal';
import { mysteryCards } from '@/data/content';

export function Mystery() {
  const icons = { eye: Eye, shield: ShieldCheck, door: DoorOpen };
  return <section className="section mystery-section" id="the-mystery"><div className="section-rail">
    <Reveal className="center-heading"><span className="eyebrow">NOT THE WHOLE STORY. NOT YET.</span><h2>Every great climb<br />starts in the <span className="gold-text">dark.</span></h2><p>We’re not ready to show everything yet. But if you’ve ever thought<br className="desktop-break" /> “I’m good, I just need one real chance,” keep your eyes on this page.</p></Reveal>
    <div className="mystery-grid">{mysteryCards.map((card, i) => { const Icon = icons[card.icon as keyof typeof icons]; return <Reveal key={card.title} delay={i * 0.07}><article className="mystery-card"><div className="card-icon"><Icon size={25} strokeWidth={1.5} /></div><span className="card-index">0{i + 1}</span><h3>{card.title}</h3><p>{card.text}</p><span className="card-edge" /></article></Reveal>; })}</div>
    <Reveal className="quiet-note"><span /> The best things don’t announce themselves. They arrive. <span /></Reveal>
  </div></section>;
}
