import { useState, type FormEvent } from 'react';
import { ArrowUpRight, CheckCircle2, LoaderCircle } from 'lucide-react';
import { pocketbaseClient } from '@/lib/pocketbase-client';
import { Reveal } from '@/components/reveal';

export function EarlyAccess() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = event.currentTarget; const data = new FormData(form);
    if (data.get('website')) return;
    setStatus('loading');
    try { await pocketbaseClient.collection('early_access').create({ email: String(data.get('email')).trim().toLowerCase(), consent: true }); setStatus('success'); form.reset(); } catch { setStatus('error'); }
  }
  return <section className="early-section" id="early-access"><Reveal className="early-rail"><div><span className="eyebrow">FIRST IN. FIRST TO KNOW.</span><h2>Be there when<br />the curtain <span className="gold-text">opens.</span></h2></div><div className="signup-block">{status === 'success' ? <div className="success-panel" role="status"><CheckCircle2 size={26} /><div><strong>You’re on the list.</strong><p>You’ll hear from us when the light is on.</p></div></div> : <form onSubmit={submit}><label htmlFor="early-email">Your email. Your front-row seat.</label><div className="signup-field"><input id="early-email" name="email" type="email" placeholder="Enter your email address" autoComplete="email" required maxLength={254} disabled={status === 'loading'} /><button className="button button-gold" type="submit" disabled={status === 'loading'}>{status === 'loading' ? <><LoaderCircle className="spin" size={17} /> Joining…</> : <>Notify Me <ArrowUpRight size={17} /></>}</button></div><input className="honeypot" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" /><p className="form-note">Only the important stuff. No noise. By joining, you agree to receive launch updates.</p>{status === 'error' && <p className="form-error" role="alert">We couldn’t save your email. Please try again.</p>}</form>}</div></Reveal></section>;
}
