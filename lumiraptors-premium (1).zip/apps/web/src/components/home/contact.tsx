import { useState, type FormEvent } from 'react';
import { ArrowUpRight, CheckCircle2, Instagram, Linkedin, LoaderCircle, Mail, MapPin, MessageCircle } from 'lucide-react';
import { Reveal } from '@/components/reveal';
import { ConfigurationLink } from '@/components/configuration-link';
import { site, isConfigured } from '@/constants/site';
import { pocketbaseClient } from '@/lib/pocketbase-client';

export function Contact() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = event.currentTarget; const data = new FormData(form); if (data.get('website')) return; setStatus('loading');
    try { await pocketbaseClient.collection('contact_messages').create({ name: String(data.get('name')).trim(), email: String(data.get('email')).trim(), message: String(data.get('message')).trim() }); setStatus('success'); form.reset(); } catch { setStatus('error'); }
  }
  const contacts = [
    { Icon: Mail, label: 'Email', value: site.email, href: isConfigured(site.email) ? `mailto:${site.email}` : site.email },
    { Icon: MessageCircle, label: 'WhatsApp', value: site.whatsapp, href: isConfigured(site.whatsapp) ? `https://wa.me/${site.whatsapp.replace(/\D/g, '')}` : site.whatsapp },
    { Icon: Linkedin, label: 'LinkedIn', value: site.linkedin, href: site.linkedin },
    { Icon: Instagram, label: 'Instagram', value: site.instagram, href: site.instagram },
  ];
  return <section className="section contact-section" id="contact"><div className="section-rail contact-grid"><Reveal><span className="eyebrow">NO NEED TO WAIT FOR THE REVEAL</span><h2>Talk <span className="gold-text">to us.</span></h2><p className="contact-intro">A question. An idea. A hello.<br />We’re listening.</p><div className="contact-details">{contacts.map(({ Icon, label, value, href }) => <div className="contact-row" key={label}><Icon size={20} strokeWidth={1.5} /><div><span>{label}</span><ConfigurationLink href={href} label={`Our ${label} contact`}>{value} <ArrowUpRight size={14} /></ConfigurationLink></div></div>)}<div className="contact-row"><MapPin size={20} strokeWidth={1.5} /><div><span>Location</span><p>{site.contactLocation}</p></div></div></div></Reveal>
    <Reveal className="contact-form-wrap" delay={0.1}>{status === 'success' ? <div className="contact-success" role="status"><CheckCircle2 size={36} /><h3>Spark received.</h3><p>We’ll get back to you soon.</p><button className="text-link" onClick={() => setStatus('idle')}>Send another message <ArrowUpRight size={16} /></button></div> : <form className="contact-form" onSubmit={submit}><h3>Leave a little spark.</h3><p>We’ll take it from here.</p><div className="form-two"><div><label htmlFor="contact-name">Name</label><input id="contact-name" name="name" placeholder="Your name" required minLength={2} maxLength={120} autoComplete="name" /></div><div><label htmlFor="contact-email">Email</label><input id="contact-email" name="email" type="email" placeholder="you@example.com" required maxLength={254} autoComplete="email" /></div></div><label htmlFor="contact-message">Message</label><textarea id="contact-message" name="message" rows={5} placeholder="What’s on your mind?" required minLength={5} maxLength={5000} /><input className="honeypot" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" /><button type="submit" className="button button-gold" disabled={status === 'loading'}>{status === 'loading' ? <><LoaderCircle size={18} className="spin" /> Sending…</> : <>Send Message <ArrowUpRight size={18} /></>}</button>{status === 'error' && <p className="form-error" role="alert">Your message couldn’t be saved. Please try again.</p>}<p className="form-note">Your details stay private. We’ll only use them to respond.</p></form>}</Reveal>
  </div></section>;
}
