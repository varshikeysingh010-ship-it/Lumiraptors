import { ArrowUpRight } from 'lucide-react';
import { Reveal } from '@/components/reveal';
import { PostCard } from '@/components/blog/post-card';
import { posts } from '@/data/posts';

export function BlogPreview() {
  const latest = [...posts]
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 3);

  return (
    <section className="section blog-preview-section" id="blog">
      <div className="section-rail">
        <Reveal className="center-heading">
          <span className="eyebrow">NOTES FROM THE CLIMB</span>
          <h2>Notes from the <span className="gold-text">climb.</span></h2>
          <p>Stories, lessons and ideas from the road to launch.</p>
        </Reveal>
        <div className="post-grid">
          {latest.map((post, index) => (
            <PostCard key={post.slug} post={post} delay={index * 0.08} />
          ))}
        </div>
        <Reveal className="blog-preview-cta">
          <a className="button button-gold" href="/blog">
            View All Posts <ArrowUpRight size={17} />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
