export const mysteryCards = [
  { title: 'Built for the overlooked', text: 'Not short on talent. Just waiting for the right opening.', icon: 'eye' },
  { title: 'Proof over promises', text: 'Less talk. Something real to put your name on.', icon: 'shield' },
  { title: 'Doors that actually open', text: 'Because a chance should be more than a word.', icon: 'door' },
];
export const climbSteps = [
  { number: '01', title: 'Start', text: 'Where the climb begins.' },
  { number: '02', title: 'Prove', text: 'Where talent becomes visible.' },
  { number: '03', title: 'Rise', text: 'Where the view changes.' },
];
export const faqs = [
  { question: 'What is LumiRaptors?', answer: 'Something we’re building carefully. The full reveal is coming soon.' },
  { question: 'When does it launch?', answer: 'Soon. Join the early list and you’ll hear first.' },
  { question: 'Who is it for?', answer: 'People ready to prove themselves, and teams who value real work.' },
  { question: 'Is it free to join the early list?', answer: 'Yes, joining the list costs nothing.' },
];
