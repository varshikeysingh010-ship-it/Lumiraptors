export type ProjectIcon = 'calendar' | 'users' | 'search' | 'pen' | 'mail' | 'lock';

export type Project = {
  id: string;
  title: string;
  description: string;
  duration: string;
  level: 'Beginner' | 'Intermediate';
  category: 'Marketing' | 'Content' | 'Research' | 'Coming Soon';
  gets: string;
  icon: ProjectIcon;
  comingSoon?: boolean;
};

export const projectCategories = [
  'All',
  'Marketing',
  'Content',
  'Research',
  'Coming Soon',
] as const;

export const projects: Project[] = [
  {
    id: 'social-calendar',
    title: 'Social Media Content Calendar',
    description: 'Plan and write 10 to 15 posts for a real startup.',
    duration: '3–5 days',
    level: 'Beginner',
    category: 'Marketing',
    gets: 'Real project, portfolio piece, certificate, mentor feedback',
    icon: 'calendar',
  },
  {
    id: 'lead-list',
    title: 'Lead List Building',
    description: 'Find and organize target customers for a startup.',
    duration: '3–5 days',
    level: 'Beginner',
    category: 'Marketing',
    gets: 'Real project, portfolio piece, certificate, mentor feedback',
    icon: 'users',
  },
  {
    id: 'competitor-research',
    title: 'Competitor Research Report',
    description: 'Study competitors and summarize what you find.',
    duration: '4–6 days',
    level: 'Intermediate',
    category: 'Research',
    gets: 'Real project, portfolio piece, certificate, mentor feedback',
    icon: 'search',
  },
  {
    id: 'blog-seo',
    title: 'Blog Writing and SEO',
    description: 'Write blog posts and research keywords.',
    duration: '5–7 days',
    level: 'Intermediate',
    category: 'Content',
    gets: 'Real project, portfolio piece, certificate, mentor feedback',
    icon: 'pen',
  },
  {
    id: 'cold-email',
    title: 'Cold Email and Message Templates',
    description: 'Write outreach messages that get replies.',
    duration: '3–4 days',
    level: 'Beginner',
    category: 'Marketing',
    gets: 'Real project, portfolio piece, certificate, mentor feedback',
    icon: 'mail',
  },
  {
    id: 'design',
    title: 'Design',
    description: 'Visual design projects are on the way.',
    duration: 'Coming soon',
    level: 'Beginner',
    category: 'Coming Soon',
    gets: 'Real project, portfolio piece, certificate, mentor feedback',
    icon: 'lock',
    comingSoon: true,
  },
  {
    id: 'video-editing',
    title: 'Video Editing',
    description: 'Video projects are coming soon.',
    duration: 'Coming soon',
    level: 'Beginner',
    category: 'Coming Soon',
    gets: 'Real project, portfolio piece, certificate, mentor feedback',
    icon: 'lock',
    comingSoon: true,
  },
  {
    id: 'data-analysis',
    title: 'Data Analysis',
    description: 'Data projects are coming soon.',
    duration: 'Coming soon',
    level: 'Beginner',
    category: 'Coming Soon',
    gets: 'Real project, portfolio piece, certificate, mentor feedback',
    icon: 'lock',
    comingSoon: true,
  },
];
