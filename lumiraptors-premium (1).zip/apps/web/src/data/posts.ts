export type PostCategory = 'Careers' | 'Startups' | 'Learning' | 'Behind the Scenes';

export type Post = {
  slug: string;
  title: string;
  excerpt: string;
  category: PostCategory;
  coverImage: string;
  /** ISO date (YYYY-MM-DD). */
  date: string;
  readingTime: string;
  author: { name: string; role: string };
  /** Shown large at the top of the blog index. */
  featured?: boolean;
  /** Lightweight markdown: ## / ### headings, > quotes, - lists, ![alt](url), **bold**, [link](url). */
  content: string;
};

export const categories: PostCategory[] = ['Careers', 'Startups', 'Learning', 'Behind the Scenes'];

export const posts: Post[] = [
  {
    slug: 'why-talented-freshers-still-dont-get-internships',
    title: 'Why talented freshers still don’t get internships',
    excerpt: 'It’s rarely about talent. It’s about visibility, proof, and the doors that never quite open. Here’s what we keep seeing — and what we want to change.',
    category: 'Careers',
    coverImage: 'https://images.hostinger.com/153d28b1-b6b5-4c25-bea1-b877903ec4ee.png',
    date: '2026-09-28',
    readingTime: '5 min read',
    author: { name: 'Varshikey', role: 'Founder, LumiRaptors' },
    featured: true,
    content: `We meet them all the time. Sharp, hungry, capable — and stuck.

They built the projects. They learned the tools. They sent the applications. And then… silence. Not rejection. Just silence. That silence is the hardest part, because it tells you nothing.

## Talent was never the problem

The gap between a talented fresher and a hired one is almost never skill. It’s **proof**. A resume says you can. A portfolio shows you did. Most freshers have the first and not the second — or they have the second, but nobody sees it.

> A chance should be more than a word on a careers page.

## What actually moves the needle

- Real work, shown publicly, that someone can judge in ten seconds
- A short, honest story about what you built and why
- One person willing to open a door instead of guarding it

The third one is the rarest. That’s the part we’re building for.

## The short version

You’re not broken. The path is. We’re not ready to show everything yet — but if you’ve ever thought *“I’m good, I just need one real chance,”* keep your eyes on this page.`,
  },
  {
    slug: 'how-small-startups-can-get-marketing-done-without-hiring',
    title: 'How small startups can get marketing work done without hiring',
    excerpt: 'You don’t need a full marketing team on day one. You need the right work, done well, on demand. Here’s the shape of a better way.',
    category: 'Startups',
    coverImage: 'https://images.hostinger.com/ed31832b-122d-4070-8676-eae1a311853d.png',
    date: '2026-09-14',
    readingTime: '6 min read',
    author: { name: 'Varshikey', role: 'Founder, LumiRaptors' },
    content: `Every early founder hits the same wall. There’s real work to be done — content, campaigns, social, the launch post — and no one to do it.

Hiring is heavy. Agencies are expensive. And the founder ends up writing the LinkedIn post at midnight. Again.

## The cost of doing it all yourself

Your time is the most expensive thing in the company. Every hour you spend on marketing is an hour you’re not spending on the product, the customers, or the next decision that only you can make.

> Founders shouldn’t be the bottleneck on their own growth.

## What a lighter model looks like

- A clear, small scope: one campaign, one asset, one goal
- Someone who can execute without a three-week onboarding
- Proof of the work before you commit to anything bigger

You don’t need a team. You need a door that opens on demand.

## We’re building toward this

We’re not ready to show the whole thing yet. But the idea is simple: real work, done by people ready to prove themselves, for teams that need it done now. If that sounds like you, keep watching.`,
  },
  {
    slug: 'what-we-learned-from-our-first-pilot-project',
    title: 'What we learned from our first pilot project',
    excerpt: 'A small project, a few brave people, and a lot of lessons. Here’s what the first real test of LumiRaptors taught us.',
    category: 'Behind the Scenes',
    coverImage: 'https://images.hostinger.com/d6ca8175-6184-4d0e-a8a7-1a2a519897c2.png',
    date: '2026-08-30',
    readingTime: '4 min read',
    author: { name: 'Varshikey', role: 'Founder, LumiRaptors' },
    content: `Before we built anything public, we ran a pilot. Small scope, real stakes, real people. This is what it taught us.

## The premise

Match someone with hunger to real work that needed doing. Step back. See what happened.

## What surprised us

- The work was better than we expected
- The confidence shift was bigger than the work itself
- The hardest part wasn’t skill — it was the first door opening

> Talent shows up the moment someone trusts it enough to let it.

## What we’re taking forward

We learned to keep the scope small, the feedback honest, and the door open. The pilot proved the shape of the idea. Now we’re building the real thing around it.

More soon. The curtain isn’t up yet — but the light is almost on.`,
  },
];

export function getPostBySlug(slug: string): Post | undefined {
  return posts.find(post => post.slug === slug);
}

export function getRelatedPosts(post: Post, limit = 3): Post[] {
  const sameCategory = posts.filter(p => p.slug !== post.slug && p.category === post.category);
  const others = posts.filter(p => p.slug !== post.slug && p.category !== post.category);
  return [...sameCategory, ...others].slice(0, limit);
}
